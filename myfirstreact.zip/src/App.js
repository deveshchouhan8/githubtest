import React from 'react';
import ReactDOM from 'react-dom';
import Blogthumb from './Blogthumb';
import Blogright from './Blogright';
import Youtube, { Hello, myYoutube } from './Callvariable';// For Single Variable Call and Multiple Variable Call
import * as allselect from './Callvariable';

function App(){
    return (
        <div className='container'>
            <div className="row">
                <div className="col-12 col-md-9 ">
                    <h2 className='p-2'>Blog List</h2>
                    <div className="row">
                        <Blogthumb />
                        <Blogthumb />
                        <Blogthumb />
                    </div>
                </div>
                <div className="col-12 col-md-3 ">
                    <h2 className='p-2'>Recent Blog</h2>
                    <div className='p-2'>
                        <Blogright />
                        <Blogright />
                        <Blogright />
                        <Blogright />
                        <Blogright />
                    </div>
                </div>
            </div>
            <div className="row">
                <h2>How To call variable value into jsx File</h2>
                <div className="col-12">
                    <b> Using with variable Call</b>
                    <ul>
                        <li>{Youtube}</li>
                        <li>{Hello}</li>
                        <li>{myYoutube()}</li>
                        
                    </ul>
                    <b> Using with Object Call </b>
                    <ul>
                        <li>{allselect.default}</li>
                        <li>{allselect.Hello}</li>
                        <li>{allselect.myYoutube()}</li>

                    </ul>
                </div>
            </div>
        </div>
           )
}
export default App;