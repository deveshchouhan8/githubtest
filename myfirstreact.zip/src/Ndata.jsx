import React from 'react';
import ReactDOM from 'react-dom';

const Ndata = [
    {
        imgsrc : "https://occ-0-2590-2164.1.nflxso.net/dnm/api/v6/Z-WHgqd_TeJxSuha8aZ5WpyLcX8/AAAABbps2fvAFwl7e8EVC7aZR8XylNmvjC7GiEsbFJubXkXVM1JDZapzI0-jIiCm00OOhrc_5Eld4liAS-tL4qDaAzolaOq6.jpg?r=366",
        title:"STRANGER THINGS",
        para:"When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces and one strange little girl.",
        link:"https://www.netflix.com/watch/80077368?multiTitleId=81253580"
    },
    {
        imgsrc:"https://occ-0-2590-2164.1.nflxso.net/dnm/api/v6/Z-WHgqd_TeJxSuha8aZ5WpyLcX8/AAAABa1GLXe6-zh1oX7eMieZj0-eNX4A7ELJtwfAgaThTModFSEK0w7Re6nOjBwHpU3nlbAMTVBnKu4SUSPLM2CfJq74TFQg.jpg?r=abb",
        title:"ELITE",
        para:"When three working-class teens enroll in an exclusive private school in Spain, the clash between them and the wealthy students leads to murder.",

        link:"https://www.netflix.com/watch/80201009?multiTitleId=81253580"
    },
    {
        imgsrc:"https://occ-0-2590-2164.1.nflxso.net/dnm/api/v6/Z-WHgqd_TeJxSuha8aZ5WpyLcX8/AAAABfmElnIKi4AXTddLZd6uMkLsNESXkTjihbtxVWq5AwdNLTO_lB7DbcIHbeAhmlHChCq-9Vi_LliTq547e03hrEPc5Bvi.jpg?r=b03",
        title:"BOSS BABY",
        para:"The Boss Baby brings his big brother Tim to the office to teach him the art of business in this animated series sprung from the hit film.",
        link:"https://www.netflix.com/watch/80077368?multiTitleId=81253580"
    }
]

export default Ndata;