import React from 'react';
import ReactDOM from 'react-dom';
import { add, sub, mult, div } from './Calc';

function App(){
    return (
        <>
            <h2>The Addition Two Number {add(20, 30)}</h2>
            <h2>The Substraction Two Number {sub(20,30)}</h2>
            <h2>The Multiplication Two Number {mult(20,30)}</h2>
            <h2>The Division Two Number {div(20, 30)}</h2>
        </>
        )
       
}
export default App;