import React, { Fragment } from 'react';
import ReactDOM from 'react-dom';

function Datetime() {

    let curDate = new Date();
    let curNowdate = curDate.getHours();
    let greeting = '';
    const cssStyle = {};

    if (curNowdate >= 1 && curNowdate <= 12) {
        greeting = "Good Morning";
        cssStyle.color='Green'
    } else if (curNowdate >= 12 && curNowdate <= 19) {
        greeting = "Good Afternoon";
        cssStyle.color = 'yellow'
    } else {
        greeting = "Good night";
        cssStyle.color = 'Black'
    }

    return (
        <h1 style={cssStyle}>Hello Friends {greeting}!</h1>
    )

}

export default Datetime;