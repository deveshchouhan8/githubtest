import React from 'react';
import ReactDOM from 'react-dom';


function Blogthumb(){
    return (
        <div className="col-3 p-2">
            <div className="card" >
                <img src="https://occ-0-2590-2164.1.nflxso.net/dnm/api/v6/Z-WHgqd_TeJxSuha8aZ5WpyLcX8/AAAABbps2fvAFwl7e8EVC7aZR8XylNmvjC7GiEsbFJubXkXVM1JDZapzI0-jIiCm00OOhrc_5Eld4liAS-tL4qDaAzolaOq6.jpg?r=366" className="card-img-top" alt="..." />
                <div className="card-body">
                    <h5 className="card-title">Card title</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href="https://www.netflix.com/watch/80077368?multiTitleId=81253580" className="btn btn-primary">Go somewhere</a>
                </div>
            </div>
        </div>
        )
           
}
export default Blogthumb;