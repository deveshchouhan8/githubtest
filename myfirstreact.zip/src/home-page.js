import React from 'react';
import ReactDOM from 'react-dom';
import Myapp from 'myapp';
function home(){
    return (
        <div>
            <Myapp/>

        </div>
           )
}
export default home;