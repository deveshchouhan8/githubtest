import React from 'react';
import ReactDOM from 'react-dom';

const Youtube = "Call Variable"
const Hello = "Call Variable";

function myYoutube() {
    let style = "Call Function"
    return (style)
        
}

export default Youtube; // For Single Variable Call
export { Hello, myYoutube }; // For Multiple Variable Call