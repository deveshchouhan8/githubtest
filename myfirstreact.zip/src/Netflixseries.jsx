import React from 'react';
import ReactDOM from 'react-dom';

function Netflixseries(props){
    return (
            <div className="col p-2">
                <div className="card card-net" >
                    <img src={props.imgsrc} className="card-img-top" alt="..." />
                    <div className="card-body">
                        <h5 className="card-title">{props.title}</h5>
                    <p className="card-text">{props.para}</p>
                        <a href={props.link} className="btn btn-primary">Watch Now</a>
                    </div>
                </div>
            </div>
        )
           
}
export default Netflixseries;