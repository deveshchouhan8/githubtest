import React from 'react';
import ReactDOM from 'react-dom';

function add(a, b) {    
    let sum = a + b; 
    return sum;
    
}
function sub(a, b) {
    let Minus = a - b;
    return Minus;
}
function mult(a, b) {
    let multiply = a * b;
    return multiply;
}
function div(a, b) {
    let division = a / b;
    division = division.toFixed(2);
    return division;
}

export { add, sub, mult, div };
