import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './index.css';
import Datetime from './Datetime'
import Youtube from './Youtube';
//import Calc from './Calc';


ReactDOM.render(<Youtube />, document.getElementById('root'));




//let curDate = new Date(2020, 5 , 5, 22);
//let curNowdate = curDate.getHours();
//let greeting = '';

//if (curNowdate >= 1 && curNowdate <= 12) {
//    greeting = "Good Morning";
//}
//else if (curNowdate >= 12 && curNowdate <= 19) {

//    greeting = "Good Afternoon";

//}
//else {
//    greeting = "Good night";
//}

//ReactDOM.render(<h1>Today Day is {greeting}</h1>, document.getElementById('root'));

//Using Fragment
//ReactDOM.render(
//    <><h1>using Babel!</h1>
//        <p>Hello Are you</p>
//        <img src="img/img1.jpg"/>
//    </>
//    , document.getElementById('root'));

//const imgOne = "https://html.quomodosoft.com/binduz/assets/images/blog-details-thumb-1.jpg";
//const imgTwo = "https://html.quomodosoft.com/binduz/assets/images/blog-details-thumb-2.jpg";
//const imgthree = "https://html.quomodosoft.com/binduz/assets/images/blog-details-thumb-1.jpg";
//ReactDOM.render(
//    <>
//        <h1>Get Date And Time</h1>
//        <div className="div-block">
//            <img src={imgOne}  />
//            <img src={imgTwo} />
//            <img src={imgthree} />
//        </div>

//    </>, document.getElementById('root'));


// Using Jsx Experssion
//const fname = "Devesh";
//const Lname = "Kumar";
//const currentdate = new Date().toLocaleDateString();
//const currenttime = new Date().toLocaleTimeString();

//ReactDOM.render('Hello How are you ' + fname + ' ' + Lname, document.getElementById('root'));
//ReactDOM.render(<h1>Hello How are you {fname} {Lname}</h1>, document.getElementById('root'));
 
//ReactDOM.render(<h1> Hello How are you {fname + ' ' + Lname} </h1>, document.getElementById('root'));
// using Literals Tamplate 
//ReactDOM.render(<h1>{'Hello How are you ${fname} ${Lname} '}</h1>, document.getElementById('root'));






// using With Array
//ReactDOM.render(
//    [<h1>using Like Array!</h1>,
//        <p>Hello Are you</p>]
//    , document.getElementById('root'));
//var h1 = document.createElement('h1');
//h1.innerHTML = "Without using Babel!";
//document.getElementById('root').appendChild(h1);