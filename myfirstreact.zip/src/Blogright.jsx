import React from 'react';
import ReactDOM from 'react-dom';


function Blogright() {
    return (       
        <div className="blogTop">
            <div>
                <img src="https://html.quomodosoft.com/binduz/assets/images/latest-post-1.jpg" />
            </div>
            <div>
                <span><i className="fa fa-calendar"></i> 24th February 2020</span>
                <a href="#">Sparks of inspiration to the new trend 2021</a>
            </div>
        </div>
        )
           
}
export default Blogright;