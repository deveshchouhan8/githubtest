import React from 'react';
import ReactDOM from 'react-dom';
import Netflixseries from './Netflixseries';
import Ndata from './Ndata';

function Youtube() {   
    return (
        <>
        <div class="jumbotron">
                <h1> TOP 6 SERIES OF NETFLIX</h1>           
        </div>
            <div className="col-md-12" style={{ 'background': 'red' }}>
                <div className="d-md-flex justify-content-around" >
                    <Netflixseries
                        imgsrc={Ndata[0].imgsrc}
                        title={Ndata[0].title}
                        para={Ndata[0].para}
                        link={Ndata[0].link}
                    />
                    <Netflixseries
                        imgsrc={Ndata[1].imgsrc}
                        title={Ndata[1].title}
                        para={Ndata[1].para}
                        link={Ndata[1].link}
                    />
                    <Netflixseries
                        imgsrc={Ndata[2].imgsrc}
                        title={Ndata[2].title}
                        para={Ndata[2].para}
                        link={Ndata[2].link}
                    />

                   
                </div>
                <div className="d-md-flex justify-content-around">
                    <Netflixseries
                        imgsrc="https://occ-0-2590-2164.1.nflxso.net/dnm/api/v6/Z-WHgqd_TeJxSuha8aZ5WpyLcX8/AAAABVFpsAgBlZ2bVLiZW_Pt8koGMNNO3nGZTT_2w9oAsnUQHhNbm58ca6a1mSXQHw9x-vZtx9zAooyovXlS22gLjqsVi2bn.jpg?r=f7f"
                        title="WHEN THEY SEE US"
                        para="Five teens from Harlem become trapped in a nightmare when they're falsely accused of a brutal attack in Central Park. Based on the true story."
                        link="https://www.netflix.com/watch/80200643?multiTitleId=81253580"
                    />
                    <Netflixseries
                        imgsrc="https://occ-0-2590-2164.1.nflxso.net/dnm/api/v6/Z-WHgqd_TeJxSuha8aZ5WpyLcX8/AAAABY_uEqlov1kHA15sPw5s7Zs532v-4ocCVuc3XDD725kXmhp45TnBrrm30pZI7Q7qoOv-Zp4ORVza8SHKlvNyK_Zxxp86.jpg?r=c7d"
                        title="LOVE IS BLIND"
                        para="Nick and Vanessa Lachey host this social experiment where single men and women look for love and get engaged, all before meeting in person"

                        link="https://www.netflix.com/watch/81006558?multiTitleId=81253580"
                    />
                    <Netflixseries
                        imgsrc="https://occ-0-2590-2164.1.nflxso.net/dnm/api/v6/Z-WHgqd_TeJxSuha8aZ5WpyLcX8/AAAABXzwXTH_87uTOhFrmYytnOO4x1rzruLrj5A1UNWDgtW6uDy5WJeU5J3-gNUfcQVqq2jxbz833FSX8ZewZXCQ6CZ6Cl7k.jpg?r=c65"
                        title="OUR PLANET"
                        para="Experience our planet's natural beauty and examine how climate change impacts all living creatures in this ambitious documentary of spectacular scope."

                        link="https://www.netflix.com/watch/80094026?multiTitleId=81253580"
                    />
                </div>
            </div>
        </>
        )
           
}
export default Youtube;